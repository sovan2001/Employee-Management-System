package com.nrifintech.spirngsecurityapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpirngsecurityappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpirngsecurityappApplication.class, args);
	}

}
