package com.nrifintech.spirngsecurityapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nrifintech.spirngsecurityapp.service.UserService;

@RestController
@RequestMapping("/HR")
public class HRController {
	@Autowired
	public UserService us;
	
	@GetMapping("/login")
	public String login() { 
		return "Welcome to HR login page";
	}
	
	@GetMapping("/login/dashboard")
	public String dashboard() { 
		return "Welcome to HR dashboard page";
	}
}

